max_date
# *** Spyder Python Console History Log ***
str(max_date.date)
str(max_date.date())
str(min_date.date())
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
from bokeh.palettes import Set1
help(Set1)
Set1[4]
Set1[7]
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
jc_stg_thresh['minor']
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
from bokeh.models.glyphs import Label
from bokeh.models import Label
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')

##---(Wed Aug 02 09:13:45 2017)---
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
thresh[str(roll_win)]
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
df.rolling
df[df.rolling > 1.0]
df
df = df.drop(df[df.rolling < 1.0].index)
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
df.drop(df[df['rolling'] < 1.0].index, inplace=True)
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
df.dropna(df['rolling'])
df.dropna()
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
max_find
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')

##---(Thu Aug 10 16:29:23 2017)---
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')

##---(Tue Aug 15 08:15:19 2017)---
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')

##---(Tue Aug 15 12:58:59 2017)---
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')

##---(Tue Aug 15 16:05:26 2017)---
runfile('D:/Projects/NWS/Python/QIN/qin_sqin_statistics.py', wdir='D:/Projects/NWS/Python/QIN')
runfile('D:/Projects/NWS/Python/STATQME/statqme_summary_table_create_csv.py', wdir='D:/Projects/NWS/Python/STATQME')
runfile('D:/Projects/NWS/Python/plot_RHAP/plot_matrix_calib_error_3bias_subplots_CHPS_export.py', wdir='D:/Projects/NWS/Python/plot_RHAP')
runfile('D:/Projects/NWS/Python/Extract_Hydro_Params/extract_hydro_params_calb_slim.py', wdir='D:/Projects/NWS/Python/Extract_Hydro_Params')
runfile('D:/Projects/NWS/Python/plot_PCAP/plot_param_ranges.py', wdir='D:/Projects/NWS/Python/plot_PCAP')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_UHG_compare.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_UH_analysis_RFC.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
runfile('D:/Projects/NWS/Python/plot_RHAP/plot_matrix_calib_error_3bias_subplots_CHPS_export.py', wdir='D:/Projects/NWS/Python/plot_RHAP')
runfile('D:/Projects/NWS/Python/Extract_Hydro_Params/extract_hydro_params_calb_slim.py', wdir='D:/Projects/NWS/Python/Extract_Hydro_Params')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_UHG_compare.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
non_zero_cnt_init
max(non_zero_cnt_init*interval,non_zero_cnt_calb*interval_check))
max(non_zero_cnt_init*interval,non_zero_cnt_calb*interval_check)
interval_check
non_zero_cnt_calb
interval_check
interval
max(non_zero_cnt_init*interval_check,non_zero_cnt_calb*interval)
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_UHG_compare.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_UHG_compare.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
runfile('D:/Software/github_sync/FY17/marfc_calb_17/Config/MARFC_refresh_coldstates_parfiles_basin.py', wdir='D:/Software/github_sync/FY17/marfc_calb_17/Config')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_Tatum_compare.py', wdir='D:/Projects/NWS/Python/UNIT_HG')

##---(Thu Aug 24 12:14:38 2017)---
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
print = da['date'].values.tolist()
test = list(set(df['date']))
test = list(set(da['date']))
p_test = []
pt_test.append(test)
p_test.append(test)
p_test=[]
p_test+=test
p_test=['sx']
p_test+=test
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
set(print_dates)
count(set(print_dates))
len(set(print_dates))
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')

##---(Fri Aug 25 07:01:48 2017)---
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
precip_site_region
precip_site_region.strip('_')
precip_site_region.pop('_')
precip_site_region.replace('_',"")
runfile('D:/Projects/Jamestown_AFWS/python/precip_alarm_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
runfile('D:/Projects/Jamestown_AFWS/python/multi_stage_gage_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
runfile('D:/Projects/Jamestown_AFWS/python/precip_stream_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')
runfile('D:/Projects/Jamestown_AFWS/python/multi_stage_gage_bokeh_html_plots.py', wdir='D:/Projects/Jamestown_AFWS/python')

##---(Mon Sep 04 14:30:26 2017)---
runfile('D:/Lynker_Employee/USGS/nexrad_study/python_scripts/plot_scripts/plot_asos_rain_snow.py', wdir='D:/Lynker_Employee/USGS/nexrad_study/python_scripts/plot_scripts')

##---(Mon Sep 04 16:06:20 2017)---
runfile('D:/Lynker_Employee/USGS/nexrad_study/python_scripts/plot_scripts/plot_asos_rain_snow.py', wdir='D:/Lynker_Employee/USGS/nexrad_study/python_scripts/plot_scripts')

##---(Mon Sep 04 16:10:56 2017)---
runfile('D:/Lynker_Employee/USGS/nexrad_study/python_scripts/plot_scripts/plot_asos_rain_snow.py', wdir='D:/Lynker_Employee/USGS/nexrad_study/python_scripts/plot_scripts')

##---(Mon Sep 04 16:25:30 2017)---
runfile('D:/USGS/nexrad_study/python_scripts/plot_scripts/plot_asos_rain_snow.py', wdir='D:/USGS/nexrad_study/python_scripts/plot_scripts')
runfile('D:/USGS/nexrad_study/python_scripts/plot_scripts/plot_asos_rain_snow.py', wdir='D:/USGS/nexrad_study/python_scripts/plot_scripts')

##---(Tue Sep 05 13:20:12 2017)---
runfile('D:/Projects/NWS/Python/Extract_Hydro_Params/extract_hydro_params_calb_slim.py', wdir='D:/Projects/NWS/Python/Extract_Hydro_Params')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_Tatum_compare.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
runfile('D:/Projects/NWS/Python/STATQME/statqme_summary_table_create_csv.py', wdir='D:/Projects/NWS/Python/STATQME')
runfile('D:/Projects/NWS/Python/QIN/qin_sqin_statistics.py', wdir='D:/Projects/NWS/Python/QIN')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_UHG_compare.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
runfile('D:/Projects/NWS/Python/UNIT_HG/plot_UH_analysis_RFC.py', wdir='D:/Projects/NWS/Python/UNIT_HG')
runfile('D:/Projects/NWS/Python/plot_PCAP/plot_param_ranges.py', wdir='D:/Projects/NWS/Python/plot_PCAP')
runfile('D:/Projects/NWS/Python/plot_RHAP/plot_matrix_calib_error_3bias_subplots_CHPS_export.py', wdir='D:/Projects/NWS/Python/plot_RHAP')
runfile('D:/Projects/NWS/Python/plot_RHAP/plot_matrix_calib_error_3bias_subplots_CHPS_export.py', wdir='D:/Projects/NWS/Python/plot_RHAP')
runfile('D:/Software/github_sync/FY17/mbrfc_calb_17/Config/MBRFC_refresh_coldstates_parfiles_basin.py', wdir='D:/Software/github_sync/FY17/mbrfc_calb_17/Config')