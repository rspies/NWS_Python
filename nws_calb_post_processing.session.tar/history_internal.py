# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***